import { SurveyResponse, CategoryType, CategoryInsights } from '../types/survey';
import { analyzeCategoryData, getSentimentColor, formatPercentage } from '../utils/dataAnalysis';
import { KPICard } from './KPICard';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { MessageSquare, TrendingUp, AlertTriangle } from 'lucide-react';
import { FeedbackLengthChart } from './FeedbackLengthChart';
import { SentimentWordCloud } from './SentimentWordCloud';
import { ComparativeSentimentChart } from './ComparativeSentimentChart';
import { UserEngagementMetrics } from './UserEngagementMetrics';
import { DataTable } from './DataTable';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface CategoryDashboardProps {
  category: CategoryType;
  data: SurveyResponse[];
  insights: CategoryInsights;
}

export function CategoryDashboard({ category, data, insights }: CategoryDashboardProps) {
  const categoryData = data.filter(item => item.category === category);
  const stats = analyzeCategoryData(data, category);
  
  const sentimentData = Object.entries(stats.sentimentDistribution).map(([sentiment, count]) => ({
    name: sentiment,
    value: count,
    color: getSentimentColor(sentiment as any)
  }));

  const sentimentScore = stats.averageSentimentScore;
  const sentimentTrend = sentimentScore > 0.2 ? 'up' : sentimentScore < -0.2 ? 'down' : 'neutral';

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-medium">{category} Analysis</h1>
        <p className="text-muted-foreground mt-2">
          Detailed insights and feedback analysis for {category.toLowerCase()}
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <KPICard
          title="Total Responses"
          value={stats.totalResponses}
          description="Category responses"
          icon={MessageSquare}
        />
        <KPICard
          title="Sentiment Score"
          value={sentimentScore.toFixed(2)}
          description={`Range: -1.0 to 1.0`}
          icon={TrendingUp}
          trend={sentimentTrend}
        />
        <KPICard
          title="Negative Feedback"
          value={stats.criticalIssuesCount}
          description="Negative feedback items"
          icon={AlertTriangle}
          trend={stats.criticalIssuesCount > 2 ? 'down' : stats.criticalIssuesCount > 0 ? 'neutral' : 'up'}
        />
      </div>

      {/* User Engagement Metrics */}
      <UserEngagementMetrics data={categoryData} />

      {/* Charts Row 1: Sentiment Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Sentiment Distribution</CardTitle>
            <p className="text-sm text-muted-foreground">
              Breakdown of feedback sentiment for this category
            </p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={sentimentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {sentimentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <ComparativeSentimentChart data={data} currentCategory={category} />
      </div>

      {/* Charts Row 2: Feedback Analysis */}
      <FeedbackLengthChart data={categoryData} />

      {/* Word Clouds */}
      <Card>
        <CardHeader>
          <CardTitle>Feedback Word Analysis</CardTitle>
          <p className="text-sm text-muted-foreground">
            Most common words used in positive and negative feedback
          </p>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="positive" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="positive">Positive Feedback</TabsTrigger>
              <TabsTrigger value="negative">Negative Feedback</TabsTrigger>
            </TabsList>
            <TabsContent value="positive" className="mt-4">
              <SentimentWordCloud data={categoryData} sentiment="Positive" />
            </TabsContent>
            <TabsContent value="negative" className="mt-4">
              <SentimentWordCloud data={categoryData} sentiment="Negative" />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Observations */}
        <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
          <CardHeader>
            <CardTitle className="text-blue-800 flex items-center">
              👁️ Key Observations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {insights.observations.map((observation, index) => (
                <div key={index} className="flex items-start p-3 bg-white/60 rounded-lg border border-blue-100 hover:border-blue-200 transition-colors">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                    <span className="text-blue-600 font-medium text-sm">{index + 1}</span>
                  </div>
                  <span className="text-sm text-blue-900 leading-relaxed">{observation}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Actionable Insights */}
        <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center">
              ✨ Actionable Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {insights.actionableInsights.map((insight, index) => (
                <div key={index} className="flex items-start p-3 bg-white/60 rounded-lg border border-green-100 hover:border-green-200 transition-colors">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3 mt-0.5">
                    <span className="text-green-600 font-medium text-sm">{index + 1}</span>
                  </div>
                  <span className="text-sm text-green-900 leading-relaxed">{insight}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Data Table */}
      <DataTable 
        data={categoryData} 
        title={`${category} Responses`} 
        maxHeight="400px"
      />
    </div>
  );
}