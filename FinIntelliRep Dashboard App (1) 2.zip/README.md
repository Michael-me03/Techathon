
  # FinIntelliRep Dashboard App

  This is a code bundle for FinIntelliRep Dashboard App. The original project is available at https://www.figma.com/design/Bur4zFgnUDw68MdQMRFpIc/FinIntelliRep-Dashboard-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  